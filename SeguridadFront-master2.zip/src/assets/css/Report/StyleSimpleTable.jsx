const StyleSimpleTable = {
    root: {
      width: '100%',
      overflowX: 'auto',
    },
    table: {
      minWidth: 700,
    },
  };

export default StyleSimpleTable;