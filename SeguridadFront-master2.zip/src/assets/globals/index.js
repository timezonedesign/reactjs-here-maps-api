
module.exports = {
    redireccionLogin:'modulo',

}
