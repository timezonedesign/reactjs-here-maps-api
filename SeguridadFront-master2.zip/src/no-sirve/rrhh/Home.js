import React, { Component } from 'react';

class Home extends Component {
    state = {  }
    render() { 
        return ( 
            <div>
                Hola desde home
            </div>
         );
    }
}
 
export default Home;