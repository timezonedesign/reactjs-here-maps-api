const StylesCarruselLogin = {
  marginTop: 65,
  width: 441,
  marginLeft: -50,
  marginRight: 'auto',
};

export default StylesCarruselLogin;