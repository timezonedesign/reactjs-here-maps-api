import React, { Component } from 'react';
import logo from '../../logo.svg';
import ButtonBases from '../../pages/index/buttonsIndex.js';

class App extends Component {
  render() {
    return (
      <div className="App">
        <ButtonBases/>
      </div>
    );
  }
}

export default App;
