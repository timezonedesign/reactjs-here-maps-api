import React, { Component } from 'react';
import Routes from './Routes';

class App extends Component {
    state = {  }
    render() { 
        return ( 
           <Routes />
        );
    }
}
 
export default App;